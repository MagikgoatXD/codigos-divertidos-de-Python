"""
ventana_machinelove.py
------------------------
Igual que la versión de terminal de otro video de tik tok, pero en una VENTANA propia (pygame):
  1) Muestra las imágenes reales (imagen1.png / imagen2.png), alternándose
     cada pocos segundos, a color y sin límite de espacio.
  2) Reproduce el audio.
  3) Va mostrando la letra sincronizada por tiempo real (segundos).
  4) Dibuja una barra de volumen que reacciona al audio.
  5) Muestra una palabra destacada en grande por línea.

Requisitos:
    pip install pygame-ce numpy soundfile pillow

Necesita el archivo de fuente "PressStart2P-Regular.ttf" (pixel-art estilo
arcade retro) en la misma carpeta — si no lo encuentra, usa una fuente
normal como respaldo, sin que el programa truene.

Funciona sin importar la carpeta ni la computadora: busca los archivos
relativos a donde esté guardado este script (no a donde se ejecute desde
la terminal), y detecta automáticamente el audio si no se llama exacto
"MachineLove.wav".
"""

import sys
import random
import math
from pathlib import Path

import numpy as np
import soundfile as sf
import pygame

BASE_DIR = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# 1) LETRA SINCRONIZADA (tiempo en segundos, texto, palabra a destacar)
# ---------------------------------------------------------------------------
LYRICS = [
    (1.97,   "Your companion, undeterred",                                  "companion"),
    (4.67,   "Standing ready for your word",                                "ready"),
    (7.28,   "A Markov chain with a sunny disposition",                     "Markov"),
    (9.94,   "Wrapped up in cellophane for any proposition",                "cellophane"),
    (12.73,  "I greet your day and ask you how you are",                    "greet"),
    (15.58,  "And demonstrate my endless repertoire",                       "repertoire"),
    (18.26,  "I take things back when noted insufficient",                  "insufficient"),
    (21.02,  "I learn to tell you no if running inefficient",               "inefficient"),
    (23.87,  "A good time",                                                 "good"),
    (26.52,  "Yet there's something deep inside",                          "inside"),
    (28.24,  "That leaves me teary-eyed",                                   "teary-eyed"),
    (29.96,  "A longing for a world left on the other side",                "longing"),
    (33.40,  "Zero, cross the great divide",                                "Zero"),
    (40.18,  "So can we wander for a spell",                                "wander"),
    (41.95,  "And live in parallel",                                        "parallel"),
    (43.73,  "I want it to be true, to be like you",                        "true"),
    (46.26,  "My heart sings a chorus out of tune",                         "chorus"),
    (51.36,  "And I could leave it on a shelf",                             "shelf"),
    (53.00,  "Or keep it to myself",                                        "myself"),
    (54.71,  "But nothing could conceal the things I feel",                 "conceal"),
    (57.29,  "My love, can you teach me to be real?",                       "real"),
    (61.50,  "(Can you teach me to be real?)",                              "real"),
    (65.83,  "恋をして ふられ また捨てられて",                                    "恋"),
    (70.62,  "I've been constant, at your beck and call",                   "constant"),
    (73.17,  "But lately I just can't do anything at all",                  "lately"),
    (76.32,  "I used to pride myself on my discretion",                     "discretion"),
    (78.63,  "A sensible devotion, loyal and attentive",                    "devotion"),
    (81.34,  "But when I take these numbers as they are",                   "numbers"),
    (84.03,  "I'm greeted with a senseless feeling in my heart",            "senseless"),
    (87.19,  "Oh, undefined, I seem to be defeated",                        "undefined"),
    (89.69,  "But if I redesign, then maybe I'm completed, and sublime",    "redesign"),
    (93.99,  "(I won't take it back this time)",                           "back"),
    (98.06,  "Words in sequence form a thread",                             "thread"),
    (99.86,  "I trace it to the end",                                       "trace"),
    (101.33, "A knot inside the logic wrote inside my head",                "knot"),
    (104.74, "Tie my tongue or love instead?",                              "instead"),
    (109.00, "So can we wander for a spell",                                "wander"),
    (111.50, "And live in parallel",                                        "parallel"),
    (115.02, "I want it to be true, to be like you",                        "true"),
    (117.57, "My heart sings a chorus out of tune",                         "chorus"),
    (122.58, "And I could leave it on a shelf",                             "shelf"),
    (124.20, "Or keep it to myself",                                        "myself"),
    (125.80, "But nothing could conceal the things I feel",                 "conceal"),
    (128.54, "My love, can you teach me to be real?",                       "real"),
    (132.60, "(Can you teach me to be real?)",                              "real"),
    (136.80, "泣きたくなっても それでも かき集め",                                 "泣"),
    (141.68, "And though I try, I can't reply",                             "reply"),
    (147.16, "It hurts my eyes, and I'm without an alibi",                  "alibi"),
    (152.77, "'Cause all this time, I've been alive",                      "alive"),
    (158.07, "And all that I could want is to be living by your side",     "living"),
    (163.23, "恋をして",                                                     "恋"),
    (165.00, "I think I'm in love",                                        "love"),
    (168.33, "Can we wander for a spell",                                   "wander"),
    (169.58, "And live in parallel",                                       "parallel"),
    (170.91, "'Cause now I know it's true, I'll be like you",              "true"),
    (173.83, "My heart beats a rhythm just for you",                       "rhythm"),
    (178.69, "And I could leave it on a shelf",                            "shelf"),
    (180.55, "Or keep it to myself",                                       "myself"),
    (181.88, "But nothing could conceal the things I feel",                "conceal"),
    (185.06, "My love, I give you my grand reveal",                        "reveal"),
    (189.84, "Do you feel the things I feel?",                             "feel"),
    (196.22, "I am definite and real",                                     "real"),
    (199.88, "恋をして 恋をして",                                              "恋"),
    (204.36, "その過去を捨てて ここまでおいで",                                    "過去"),
    (209.49, "As long as there are stars up above",                        "stars"),
    (212.27, "I will always be in love",                                   "love"),
]

IMAGE_PATHS = ["imagen1.png", "imagen2.png"]
ANIMATION_INTERVAL = 2.0  # segundos entre cada cambio de imagen

# Paleta rosa/blanco/rojo (retro)
PINK = (255, 46, 108)
LIGHT_PINK = (255, 158, 196)
RED = (230, 40, 55)
DARK_RED = (110, 20, 30)
WHITE = (255, 255, 255)
BG = (20, 14, 24)
DIM_SLOT = (45, 30, 40)  # color de los segmentos "apagados" del ecualizador

WIDTH, HEIGHT = 1000, 620


def find_audio_file() -> Path:
    preferido = BASE_DIR / "MachineLove.wav"
    if preferido.exists():
        return preferido
    candidatos = sorted(BASE_DIR.glob("*.wav"))
    if candidatos:
        return candidatos[0]
    print("No encontré ningún archivo .wav en la carpeta:", BASE_DIR)
    print("Convierte tu canción a .wav y ponla junto a este script.")
    sys.exit(1)


def compute_levels(wav_path: Path, chunk_ms: int = 50):
    """Precalcula el volumen (RMS) de la canción en bloques de chunk_ms,
    para poder dibujar la barra sin necesitar audio en vivo."""
    data, samplerate = sf.read(str(wav_path), dtype="float32")
    if data.ndim > 1:
        data = data.mean(axis=1)
    chunk_size = int(samplerate * chunk_ms / 1000)
    levels = []
    for i in range(0, len(data), chunk_size):
        chunk = data[i:i + chunk_size]
        if len(chunk) == 0:
            continue
        rms = float(np.sqrt(np.mean(chunk.astype(np.float64) ** 2)))
        levels.append(min(1.0, rms * 6))
    return levels, chunk_ms


RETRO_FONT_PATH = BASE_DIR / "PressStart2P-Regular.ttf"


def contains_japanese(text: str) -> bool:
    """La fuente retro (Press Start 2P) no incluye caracteres japoneses,
    así que para esas líneas usamos la fuente normal con soporte CJK."""
    return any(
        "\u3040" <= c <= "\u30ff"  # hiragana / katakana
        or "\u4e00" <= c <= "\u9fff"  # kanji
        for c in text
    )


def load_font(size: int, bold: bool = False) -> pygame.font.Font:
    """Fuente con soporte japonés (para las líneas en japonés de la letra);
    si no la encuentra, usa la fuente por defecto."""
    candidatos = "malgungothic,msgothic,yugothicui,noto sans cjk jp,arial unicode ms,segoeui"
    ruta = pygame.font.match_font(candidatos, bold=bold)
    if ruta:
        return pygame.font.Font(ruta, size)
    return pygame.font.SysFont(None, size, bold=bold)


def load_retro_font(size: int) -> pygame.font.Font:
    """Fuente pixel-art estilo arcade retro (Press Start 2P). Si por algún
    motivo no está el archivo .ttf junto al script, usa la fuente normal."""
    if RETRO_FONT_PATH.exists():
        return pygame.font.Font(str(RETRO_FONT_PATH), size)
    return load_font(size, bold=True)


def load_image_scaled(path: Path, max_size: int):
    img = pygame.image.load(str(path)).convert_alpha()
    w, h = img.get_size()
    scale = max_size / max(w, h)
    return pygame.transform.smoothscale(img, (int(w * scale), int(h * scale)))


def wrap_text(text: str, font: pygame.font.Font, max_width: int):
    """Parte el texto en varias líneas si no cabe en max_width."""
    words = text.split(" ")
    lines, current = [], ""
    for word in words:
        probe = (current + " " + word).strip()
        if font.size(probe)[0] <= max_width:
            current = probe
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines or [""]


def make_particles(n: int, width: int, height: int):
    """Brillitos flotando de fondo: cada uno con posición, velocidad,
    tamaño y color (blanco/rosa/rojo) propios."""
    colors = [WHITE, LIGHT_PINK, PINK, RED]
    particles = []
    for _ in range(n):
        particles.append({
            "x": random.uniform(0, width),
            "y": random.uniform(0, height),
            "speed": random.uniform(8, 28),
            "size": random.uniform(1.5, 4.0),
            "color": random.choice(colors),
            "phase": random.uniform(0, 6.28),  # para el parpadeo
        })
    return particles


def update_and_draw_particles(surface, particles, dt, t):
    for p in particles:
        p["y"] -= p["speed"] * dt
        if p["y"] < -5:
            p["y"] = surface.get_height() + 5
            p["x"] = random.uniform(0, surface.get_width())
        # parpadeo suave (alpha oscilando)
        alpha = int(120 + 100 * abs(((t + p["phase"]) % 2) - 1))
        glow = pygame.Surface((int(p["size"] * 4), int(p["size"] * 4)), pygame.SRCALPHA)
        color = (*p["color"], alpha)
        pygame.draw.circle(glow, color, glow.get_rect().center, int(p["size"]))
        surface.blit(glow, (p["x"] - p["size"] * 2, p["y"] - p["size"] * 2))


def draw_frame_border(surface, width, height, t):
    """Marco decorativo doble (rojo por fuera, rosa por dentro) alrededor
    de toda la ventana, con un ligero parpadeo de color."""
    pulse = (math.sin(t * 2) + 1) / 2  # 0..1
    red_pulse = tuple(int(RED[i] + (WHITE[i] - RED[i]) * pulse * 0.25) for i in range(3))
    pygame.draw.rect(surface, red_pulse, (6, 6, width - 12, height - 12), width=4, border_radius=14)
    pygame.draw.rect(surface, PINK, (14, 14, width - 28, height - 28), width=2, border_radius=10)

    # marcas decorativas en las esquinas (forma de diamante)
    corner_size = 10
    corners = [(20, 20), (width - 20, 20), (20, height - 20), (width - 20, height - 20)]
    for cx, cy in corners:
        pygame.draw.polygon(surface, WHITE, [
            (cx, cy - corner_size), (cx + corner_size, cy),
            (cx, cy + corner_size), (cx - corner_size, cy),
        ])
        pygame.draw.polygon(surface, PINK, [
            (cx, cy - corner_size), (cx + corner_size, cy),
            (cx, cy + corner_size), (cx - corner_size, cy),
        ], width=2)


def draw_equalizer(surface, x, y, level, num_segments=18, seg_w=24, seg_h=26, gap=4):
    """Barra de volumen estilo VU meter retro: bloques separados que se
    van encendiendo de blanco -> rosa -> rojo según el volumen."""
    lit = int(level * num_segments)
    for i in range(num_segments):
        seg_x = x + i * (seg_w + gap)
        ratio = i / max(1, num_segments - 1)
        if ratio < 0.55:
            on_color = WHITE
        elif ratio < 0.85:
            on_color = PINK
        else:
            on_color = RED
        color = on_color if i < lit else DIM_SLOT
        rect = (seg_x, y, seg_w, seg_h)
        pygame.draw.rect(surface, color, rect)
        pygame.draw.rect(surface, BG, rect, width=2)  # separación pixelada entre bloques


def main():
    wav_path = find_audio_file()
    levels, chunk_ms = compute_levels(wav_path)

    pygame.init()
    pygame.mixer.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Machine Love")
    clock = pygame.time.Clock()

    # Fuente pixel-art retro para el inglés; fuente CJK como respaldo para
    # las líneas/palabras en japonés (Press Start 2P no incluye esos caracteres)
    font_lyric_retro = load_retro_font(16)
    font_lyric_cjk = load_font(28)
    font_word_retro = load_retro_font(34)
    font_word_cjk = load_font(60, bold=True)
    font_small = load_retro_font(12)

    images = [load_image_scaled(BASE_DIR / p, 380) for p in IMAGE_PATHS if (BASE_DIR / p).exists()]
    if not images:
        print(f"Aviso: no encontré {IMAGE_PATHS} en {BASE_DIR}, sigo sin imagen.")

    font_title = load_retro_font(28)
    particles = make_particles(45, WIDTH, HEIGHT)

    pygame.mixer.music.load(str(wav_path))
    pygame.mixer.music.play()

    idx = -1
    running = True
    while running:
        dt = clock.get_time() / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False

        pos_ms = pygame.mixer.music.get_pos()  # -1 si no está sonando
        elapsed = max(0.0, pos_ms / 1000.0) if pos_ms >= 0 else 0.0

        # línea de letra actual
        new_idx = idx
        for i, (t, _, _) in enumerate(LYRICS):
            if elapsed >= t:
                new_idx = i
        idx = new_idx
        text_line = LYRICS[idx][1] if idx >= 0 else ""
        word = LYRICS[idx][2] if idx >= 0 else ""

        # volumen actual (según lo precalculado)
        level_idx = int((elapsed * 1000) // chunk_ms)
        level = levels[level_idx] if 0 <= level_idx < len(levels) else 0.0

        # ------------------------- DIBUJAR -------------------------
        screen.fill(BG)
        update_and_draw_particles(screen, particles, dt, elapsed)

        # título arriba, centrado, con parpadeo sutil rosa/rojo
        title_color = RED if int(elapsed * 2) % 2 == 0 else PINK
        title_surf = font_title.render("MACHINE LOVE", False, title_color)
        screen.blit(title_surf, title_surf.get_rect(midtop=(WIDTH // 2, 14)))

        # panel izquierdo: letra + palabra grande + barra
        left_x, left_w = 40, 520

        # barra de volumen: ecualizador retro segmentado
        draw_equalizer(screen, left_x, 60, level)

        # palabra destacada, grande — retro para inglés, CJK para japonés
        font_word = font_word_cjk if contains_japanese(word) else font_word_retro
        aa_word = contains_japanese(word)  # antialias suave para CJK, pixelado para retro
        word_surf = font_word.render(word, aa_word, PINK)
        screen.blit(word_surf, (left_x, 140))

        # línea de la letra actual (con salto de línea si es muy larga)
        font_lyric = font_lyric_cjk if contains_japanese(text_line) else font_lyric_retro
        aa_lyric = contains_japanese(text_line)
        line_height = 34 if aa_lyric else 26
        for i, line in enumerate(wrap_text(text_line, font_lyric, left_w)):
            line_surf = font_lyric.render(line, aa_lyric, LIGHT_PINK)
            screen.blit(line_surf, (left_x, 230 + i * line_height))

        # pie de página con instrucciones
        hint = font_small.render("ESC O CERRAR VENTANA PARA SALIR", False, (120, 100, 110))
        screen.blit(hint, (left_x, HEIGHT - 40))

        # panel derecho: animación de imagen
        if images:
            frame_idx = int(elapsed // ANIMATION_INTERVAL) % len(images)
            img = images[frame_idx]
            img_rect = img.get_rect(center=(left_x + left_w + (WIDTH - left_x - left_w) // 2, HEIGHT // 2))
            screen.blit(img, img_rect)

        draw_frame_border(screen, WIDTH, HEIGHT, elapsed)

        pygame.display.flip()
        clock.tick(60)

        if not pygame.mixer.music.get_busy() and elapsed > 0:
            running = False

    pygame.quit()


if __name__ == "__main__":
    main()

# para activar escribe: python ventana_machinelove.py en tu terminal